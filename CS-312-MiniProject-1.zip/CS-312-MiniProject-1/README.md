# CS-312-MiniProject-1

## Blog Web Application Using Node.js, Express.js, and EJS

This project is a basic blog web application built with Node.js, Express.js, and EJS. Users can create, view, edit, delete, and filter blog posts by category. Posts are stored temporarily in a server-side array, so they do not persist after the server restarts.

## Features

- Create blog posts with creator name, title, category, timestamp, and content
- View all blog posts on the homepage
- Edit existing posts with a pre-filled form
- Delete posts
- Filter posts by category
- Responsive CSS layout for desktop and mobile

## Technologies Used

- Node.js
- Express.js
- EJS
- HTML
- CSS
- JavaScript

## How to Run

1. Clone the repository:

```bash
git clone https://github.com/YOUR-USERNAME/CS-312-MiniProject-1.git
```

2. Move into the project folder:

```bash
cd CS-312-MiniProject-1
```

3. Install dependencies:

```bash
npm install
```

4. Start the application:

```bash
npm start
```

5. Open the app in a browser:

```text
http://localhost:3000
```

## Project Structure

```text
CS-312-MiniProject-1/
├── app.js
├── package.json
├── README.md
├── public/
│   └── styles.css
└── views/
    ├── edit.ejs
    ├── index.ejs
    └── partials/
        ├── footer.ejs
        └── header.ejs
```

## Notes

This project does not use a database. Blog posts are stored in memory and reset when the server restarts.
